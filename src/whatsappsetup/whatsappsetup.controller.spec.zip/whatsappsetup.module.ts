import { Module } from '@nestjs/common';
import { WhatsappSetupService } from './whatsappsetup.service';
import { HttpModule } from '@nestjs/axios';
import { HttpService } from '../common/utils/http.service';
import { WhatsappsetupController } from './whatsappsetup.controller';
import { PrismaModule } from 'src/prisma/prisma.module';
import { EncryptionModule } from '../common/encryption/encryption.module';

@Module({
  imports: [HttpModule,PrismaModule,EncryptionModule],
  providers: [WhatsappSetupService, HttpService],
  exports: [WhatsappSetupService],
  controllers: [WhatsappsetupController],
})
export class WhatsappsetupModule {}

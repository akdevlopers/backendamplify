import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import axios from 'axios';
import * as dotenv from 'dotenv';
import * as crypto from 'crypto';
import { PrismaService } from 'src/prisma/prisma.service';
import { WhatsappSettingDto } from './dto/whatsappsetup.dto';
import { v4 as uuidv4 } from 'uuid';
import { EncryptionService } from '../common/encryption/encryption.service';
dotenv.config();

@Injectable()

export class WhatsappSetupService {
  private readonly baseApiEndpoint = process.env.BASE_API_ENDPOINT;
  private readonly appId = process.env.EMBEDDED_SIGNUP_APP_ID ?? '';
  private readonly appSecret = process.env.EMBEDDED_SIGNUP_APP_SECRET ?? '';

  constructor(
    private readonly prisma: PrismaService,
    private readonly encryptionService: EncryptionService,
  ) {}


   async processEmbeddedSignUp(request_code,waba_id,phone_number_id,vendorUid){
    try {
       if (!request_code || !waba_id || !phone_number_id || !vendorUid) {
          throw new HttpException('All parameters are required and must not be empty',HttpStatus.BAD_REQUEST);
        }
        
      const vendorRecord = await this.prisma.vendors.findFirst({
        where: {
          uid: vendorUid,
        },
      });

      if (vendorRecord) {
        
      } else {

        return 'Invalid Vendor UID';
      }

      const vendorID=vendorRecord.id;
    

      // Step 1: Generate Access Token
      const tokenResponse = await axios.post(
        `${this.baseApiEndpoint}oauth/access_token`,
        null,
        {
          params: {
            client_id: this.appId,
            client_secret: this.appSecret,
            code: request_code,
          },
        },
      );
      
      const accessToken = tokenResponse.data.access_token;
      if (!accessToken) {
        throw new HttpException('Failed to get Access token', HttpStatus.BAD_REQUEST);
      }
      const encryptedAccessToken=this.encryptionService.encrypt(accessToken);
      const encryptedwaba_id=this.encryptionService.encrypt(waba_id);
      const encryptedphone_number_id=this.encryptionService.encrypt(phone_number_id);
      const encryptedfacebook_app_id=this.encryptionService.encrypt(this.appId);
      const encryptedfacebook_app_secret=this.encryptionService.encrypt(this.appSecret);

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'whatsapp_access_token',
          },
        },
        update: {
          value: encryptedAccessToken,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'whatsapp_access_token',
          value: encryptedAccessToken,
          status: null,
          data_type: 1,
        },
      });

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'whatsapp_business_account_id',
          },
        },
        update: {
          value: encryptedwaba_id,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'whatsapp_business_account_id',
          value: encryptedwaba_id,
          status: null,
          data_type: 1,
        },
      });

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'current_phone_number_id',
          },
        },
        update: {
          value: encryptedphone_number_id,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'current_phone_number_id',
          value: encryptedphone_number_id,
          status: null,
          data_type: 1,
        },
      });


      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'facebook_app_id',
          },
        },
        update: {
          value: encryptedfacebook_app_id,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'facebook_app_id',
          value: encryptedfacebook_app_id,
          status: null,
          data_type: 1,
        },
      });

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'facebook_app_secret',
          },
        },
        update: {
          value: encryptedfacebook_app_secret,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'facebook_app_secret',
          value: encryptedfacebook_app_secret,
          status: null,
          data_type: 1,
        },
      });

      // const accessToken = this.encryptionService.decrypt('5ef645ef4fb86dee34311fb538cac1d2a2086249013e47f47595633e14aa0410b307a94aca03140a9969f219680e1f4f595546a1af6685cf1acce944e0ec99a71654e66f4d7ea89fe8c20bfc4778d64c2e2845c3d8e43e6de386bd8200ce307925919440e9c1c7a28b4f9b21df531a9b64fb734afca0e637301291824824f2b8d051b7d2645c51d78a3eb6d4ed51d6e3af2c2473cfb6f4b322adceac1f8a49510d2998585bea2830c5ecca6e49b40b5649aec3dac4e439f6545ee6556e224037866111ef743d348ec5c8af786bab061b62cbf4012a975a249cb2804087438af42770d54d1dcba8fcec711307a0999b59c69e6a29dc43c2ed93debdb37b3a03e2');

      // Step 2: Verify Phone Number Records
      const phoneNumbersResponse = await axios.get(
        `${this.baseApiEndpoint}${waba_id}/phone_numbers`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      );

      const phoneNumberRecord = phoneNumbersResponse.data.data.find(
        (number) => number.id === phone_number_id,
      );

      const displayPhoneNumber = phoneNumberRecord?.display_phone_number;
      if (!displayPhoneNumber) {
        throw new Error(`Phone number with id ${phone_number_id} not found.`);
      }
      // Step 3: Register Phone Number if Not Registered
      if (!phoneNumberRecord || phoneNumberRecord.platform_type !== 'CLOUD_API') {
        const phoneRegistration = await axios.post(
          `${this.baseApiEndpoint}${phone_number_id}/register`,
          {
            messaging_product: 'whatsapp',
            pin: '123456',
          },
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
            },
          },
        );
        const phoneRegistrationStatus=phoneRegistration.data.success;

        if (!phoneRegistrationStatus) {
          throw new HttpException('Failed Phone number registration', HttpStatus.BAD_REQUEST);
        }else if(phoneRegistrationStatus != true)
        {
          throw new HttpException('Failed Phone number registration', HttpStatus.BAD_REQUEST);
        }
      }

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'whatsapp_phone_numbers',
          },
        },
        update: {
          value: JSON.stringify(phoneNumbersResponse.data.data),
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'whatsapp_phone_numbers',
          value: JSON.stringify(phoneNumbersResponse.data.data),
          status: null,
          data_type: 1,
        },
      });

      const encryptedcurrent_phone_number_number=this.encryptionService.encrypt(displayPhoneNumber);

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'current_phone_number_number',
          },
        },
        update: {
          value: encryptedcurrent_phone_number_number,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'current_phone_number_number',
          value: encryptedcurrent_phone_number_number,
          status: null,
          data_type: 1,
        },
      });

      const encryptedvendor_api_access_token=this.encryptionService.encrypt(generateSha1Hash(vendorUid));

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'vendor_api_access_token',
          },
        },
        update: {
          value: encryptedvendor_api_access_token,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'vendor_api_access_token',
          value: encryptedvendor_api_access_token,
          status: null,
          data_type: 1,
        },
      });


      // Step 4: Subscribe to Webhook

      // Delete the existing override callback webhook URL 
      await axios.post(
        `${this.baseApiEndpoint}${waba_id}/subscribed_apps`,
        {},
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      );

    // Create or Update New override callback webhook URL 
      const webhookUrl = `https://app.salegrowy.com/whatsapp-webhook/${vendorUid}`;
      await axios.post(
        `${this.baseApiEndpoint}${waba_id}/subscribed_apps`,
        {
          override_callback_uri: webhookUrl,
          verify_token: generateSha1Hash(vendorUid),
        },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      );

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'webhook_verified_at',
          },
        },
        update: {
          value: new Date().toISOString(),
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'webhook_verified_at',
          value: new Date().toISOString(),
          status: null,
          data_type: 1,
        },
      });

      // Get Details
      const webhookOverrides = axios.get(`${this.baseApiEndpoint}${waba_id}/subscribed_apps`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
        params: {
          // Add your query parameters here
          // For example: key1: 'value1', key2: 'value2'
        },
      });

      await this.refreshHealthStatus(vendorUid);
      
     // Step 5: Finalize Setup
      // Save necessary data to your database or perform additional setup as needed

      return 'You are now connected to WhatsApp Cloud API' ;
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }


  async refreshHealthStatus(vendorUid){
    try {
       if (!vendorUid) {
          throw new HttpException('All parameters are required and must not be empty',HttpStatus.BAD_REQUEST);
        }
        
      const vendorRecord = await this.prisma.vendors.findFirst({
        where: {
          uid: vendorUid,
        },
      });

      if (vendorRecord) {
        
      } else {

        return 'Invalid Vendor UID';
      }

      const vendorID=vendorRecord.id;


      const vendorSettingsRecord = await this.prisma.vendorSettings.findMany({
        where: {
          vendors__id: vendorID,
          name: {
            in: ['whatsapp_access_token', 'whatsapp_business_account_id','current_phone_number_id'],
          },
        },
      });

      if (!vendorSettingsRecord || vendorSettingsRecord.length < 3) {
        throw new HttpException('WhatsApp Access Token or WABA ID not found', HttpStatus.BAD_REQUEST);
      }
       
      const accessTokenRecord = vendorSettingsRecord.find(item => item.name === 'whatsapp_access_token');
      const wabaidRecord = vendorSettingsRecord.find(item => item.name === 'whatsapp_business_account_id') ?? "";
      const phonenumberidRecord = vendorSettingsRecord.find(item => item.name === 'current_phone_number_id') ?? "";

      if (!accessTokenRecord || !wabaidRecord || !phonenumberidRecord) {
        throw new HttpException('Required settings not found', HttpStatus.BAD_REQUEST);
      }

      const accessToken = this.encryptionService.decrypt(accessTokenRecord.value);
      const waba_id = this.encryptionService.decrypt(wabaidRecord.value);
      const phone_number_id = this.encryptionService.decrypt(phonenumberidRecord.value);
      // Health Status
      const healthStatus = await axios.get(
        `${this.baseApiEndpoint}${waba_id}/phone_numbers?fields=health_status`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      );


      const filteredData = healthStatus.data.data.find(item => item.id === phone_number_id);

      const healthData = {
        [waba_id]: {
          whatsapp_business_account_id: waba_id,
          health_status_updated_at: new Date(),
          health_status_updated_at_formatted:  new Date().toString(),
          health_data: filteredData,
        }
      };
      
      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'whatsapp_health_status_data',
          },
        },
        update: {
          value:JSON.stringify(healthData),
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'whatsapp_health_status_data',
          value: JSON.stringify(healthData),
          status: null,
          data_type: 1,
        },
      });

      return 'Health Status Updated' ;
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
  async syncPhoneNumbers(vendorUid){
    try {
       if (!vendorUid) {
          throw new HttpException('All parameters are required and must not be empty',HttpStatus.BAD_REQUEST);
        }
        
      const vendorRecord = await this.prisma.vendors.findFirst({
        where: {
          uid: vendorUid,
        },
      });

      if (vendorRecord) {
        
      } else {

        return 'Invalid Vendor UID';
      }

      const vendorID=vendorRecord.id;


      const vendorSettingsRecord = await this.prisma.vendorSettings.findMany({
        where: {
          vendors__id: vendorID,
          name: {
            in: ['whatsapp_access_token', 'whatsapp_business_account_id','current_phone_number_id'],
          },
        },
      });

      if (!vendorSettingsRecord || vendorSettingsRecord.length < 3) {
        throw new HttpException('WhatsApp Access Token or WABA ID not found', HttpStatus.BAD_REQUEST);
      }
       
      const accessTokenRecord = vendorSettingsRecord.find(item => item.name === 'whatsapp_access_token');
      const wabaidRecord = vendorSettingsRecord.find(item => item.name === 'whatsapp_business_account_id') ?? "";
      const phonenumberidRecord = vendorSettingsRecord.find(item => item.name === 'current_phone_number_id') ?? "";

      if (!accessTokenRecord || !wabaidRecord || !phonenumberidRecord) {
        throw new HttpException('Required settings not found', HttpStatus.BAD_REQUEST);
      }

      const accessToken = this.encryptionService.decrypt(accessTokenRecord.value);
      const waba_id = this.encryptionService.decrypt(wabaidRecord.value);
      const phone_number_id = this.encryptionService.decrypt(phonenumberidRecord.value);

      // Verify Phone Number Records
      const phoneNumbersResponse = await axios.get(
        `${this.baseApiEndpoint}${waba_id}/phone_numbers`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      );

      const phoneNumberRecord = phoneNumbersResponse.data.data.find(
        (number) => number.id === phone_number_id,
      );

      const displayPhoneNumber = phoneNumberRecord?.display_phone_number;
      if (!displayPhoneNumber) {

        const  displayPhoneNumbers = phoneNumbersResponse.data.data[0];
        const displayPhoneNumber=displayPhoneNumbers?.display_phone_number;
        const phone_number_id=displayPhoneNumbers?.id;
        
      }
      // Step 3: Register Phone Number if Not Registered
      if (!phoneNumberRecord || phoneNumberRecord.platform_type !== 'CLOUD_API') {
        const phoneRegistration = await axios.post(
          `${this.baseApiEndpoint}${phone_number_id}/register`,
          {
            messaging_product: 'whatsapp',
            pin: '123456',
          },
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
            },
          },
        );
        const phoneRegistrationStatus=phoneRegistration.data.success;

        if (!phoneRegistrationStatus) {
          throw new HttpException('Failed Phone number registration', HttpStatus.BAD_REQUEST);
        }else if(phoneRegistrationStatus != true)
        {
          throw new HttpException('Failed Phone number registration', HttpStatus.BAD_REQUEST);
        }
      }

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'whatsapp_phone_numbers',
          },
        },
        update: {
          value: JSON.stringify(phoneNumbersResponse.data.data),
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'whatsapp_phone_numbers',
          value: JSON.stringify(phoneNumbersResponse.data.data),
          status: null,
          data_type: 1,
        },
      });

      const encryptedcurrent_phone_number_number=this.encryptionService.encrypt(displayPhoneNumber);

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'current_phone_number_number',
          },
        },
        update: {
          value: encryptedcurrent_phone_number_number,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'current_phone_number_number',
          value: encryptedcurrent_phone_number_number,
          status: null,
          data_type: 1,
        },
      });
      
      const encryptedphone_number_id=this.encryptionService.encrypt(phone_number_id);

      await this.prisma.vendorSettings.upsert({
        where: {
          vendors__id_name: {
            vendors__id: vendorID,
            name: 'current_phone_number_id',
          },
        },
        update: {
          value: encryptedphone_number_id,
          status: null,
          data_type: 1,
        },
        create: {
          uid: uuidv4(),
          vendors__id: vendorID,
          name: 'current_phone_number_id',
          value: encryptedphone_number_id,
          status: null,
          data_type: 1,
        },
      });

      return "Phone Number Synced Successfully";
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async createTemplate(name,language,components,vendorUid){
    try {
       if (!name || !language || !components || !vendorUid ) {
          throw new HttpException('All parameters are required and must not be empty',HttpStatus.BAD_REQUEST);
        }
        
      const vendorRecord = await this.prisma.vendors.findFirst({
        where: {
          uid: vendorUid,
        },
      });

      if (vendorRecord) {
        
      } else {

        return 'Invalid Vendor UID';
      }

      const vendorID=vendorRecord.id;


      

      return "Success";
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
}

function generateSha1Hash(input: string): string {
  return crypto.createHash('sha1').update(input).digest('hex');
}

